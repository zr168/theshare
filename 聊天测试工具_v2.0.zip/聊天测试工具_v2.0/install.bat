@echo off
chcp 65001 >nul
title AI聊天测试工具 - 自动安装
color 0A

echo.
echo ╔════════════════════════════════════════════════════╗
echo ║                                                    ║
echo ║     AI聊天自动测试工具 - 一键安装程序             ║
echo ║                                                    ║
echo ╚════════════════════════════════════════════════════╝
echo.
echo 此脚本将自动完成以下操作:
echo   1. 检查 Python 环境
echo   2. 创建 Python 虚拟环境
echo   3. 安装必要的依赖包
echo   4. 安装 Playwright 浏览器
echo.
echo 预计需要 3-5 分钟，请耐心等待...
echo.
pause
echo.

REM ============================================
REM 步骤 1: 检查 Python
REM ============================================
echo [1/4] 检查 Python 环境...
python --version >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo ❌ 错误: 未找到 Python
    echo.
    echo 请先安装 Python 3.11 或更高版本
    echo 下载地址: https://www.python.org/downloads/
    echo.
    echo 安装时请勾选 "Add Python to PATH"
    echo.
    pause
    exit /b 1
)

python --version
echo ✓ Python 已安装
echo.

REM ============================================
REM 步骤 2: 创建虚拟环境（可选）
REM ============================================
echo [2/4] 准备 Python 环境...

if exist "venv\" (
    echo ✓ 虚拟环境已存在
) else (
    echo 创建虚拟环境...
    python -m venv venv
    if %ERRORLEVEL% NEQ 0 (
        echo ⚠️  虚拟环境创建失败，使用全局环境继续...
    ) else (
        echo ✓ 虚拟环境创建成功
    )
)
echo.

REM 激活虚拟环境（如果存在）
if exist "venv\Scripts\activate.bat" (
    call venv\Scripts\activate.bat
    echo ✓ 已激活虚拟环境
    echo.
)

REM ============================================
REM 步骤 3: 安装依赖
REM ============================================
echo [3/4] 安装 Python 依赖包...
echo 正在安装 playwright...
pip install playwright --upgrade
if %ERRORLEVEL% NEQ 0 (
    echo ❌ 依赖安装失败
    pause
    exit /b 1
)
echo ✓ 依赖安装完成
echo.

REM ============================================
REM 步骤 4: 安装 Playwright 浏览器
REM ============================================
echo [4/4] 安装 Playwright 浏览器驱动...
echo 这可能需要几分钟，请耐心等待...
echo.
playwright install chromium
if %ERRORLEVEL% NEQ 0 (
    echo ⚠️  浏览器驱动安装可能不完整
    echo    如果后续运行出错，请手动执行:
    echo    playwright install chromium
    echo.
) else (
    echo ✓ 浏览器驱动安装完成
)
echo.

REM ============================================
REM 安装完成
REM ============================================
echo.
echo ╔════════════════════════════════════════════════════╗
echo ║                                                    ║
echo ║              ✓ 安装完成！                         ║
echo ║                                                    ║
echo ╚════════════════════════════════════════════════════╝
echo.
echo 接下来可以:
echo   1. 双击运行 "快速开始.bat" 开始使用
echo   2. 或查看 "使用手册.md" 了解详细说明
echo.
echo 按任意键退出...
pause >nul
