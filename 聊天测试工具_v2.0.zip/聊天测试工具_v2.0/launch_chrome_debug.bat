@echo off
echo ====================================
echo   启动 Chrome 调试模式
echo ====================================
echo.
echo 此脚本将启动一个支持远程调试的 Chrome 实例
echo 端口: 9222
echo.

REM 查找 Chrome 安装路径
set CHROME_PATH=""

if exist "C:\Program Files\Google\Chrome\Application\chrome.exe" (
    set CHROME_PATH="C:\Program Files\Google\Chrome\Application\chrome.exe"
) else if exist "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe" (
    set CHROME_PATH="C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"
) else if exist "%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe" (
    set CHROME_PATH="%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"
)

if %CHROME_PATH%=="" (
    echo ❌ 错误: 找不到 Chrome 浏览器
    echo 请手动指定 Chrome 路径
    pause
    exit /b 1
)

echo 找到 Chrome: %CHROME_PATH%
echo.
echo 正在启动...
echo.

REM 创建临时用户数据目录
set USER_DATA_DIR=%TEMP%\chrome-debug

REM 启动 Chrome
%CHROME_PATH% --remote-debugging-port=9222 --user-data-dir="%USER_DATA_DIR%" http://118.113.15.18:8015/ai-chat-ui/

echo.
echo ✓ Chrome 已启动
echo.
echo 接下来的步骤:
echo 1. 在打开的 Chrome 中登录
echo 2. 导航到知识库助手页面
echo 3. 运行测试脚本: python auto_chat_tester_v2.py --set ... --database ... --use-existing
echo.
echo 按任意键关闭此窗口...
pause >nul
