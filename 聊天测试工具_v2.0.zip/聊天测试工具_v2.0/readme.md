太好了！现在让我帮你创建一个完整的分发包。我会创建：

1. **一键安装脚本**
2. **一键启动脚本**
3. **完整的使用文档**
4. **打包说明**好的，现在让我创建一个完整的分发方案。我会创建以下文件：

## 📦 创建分发包

### 1️⃣ **安装脚本** - `install.bat`

创建这个文件，同事双击即可完成所有安装：

```batch
@echo off
chcp 65001 >nul
title AI聊天测试工具 - 自动安装
color 0A

echo.
echo ╔════════════════════════════════════════════════════╗
echo ║                                                    ║
echo ║     AI聊天自动测试工具 - 一键安装程序             ║
echo ║                                                    ║
echo ╚════════════════════════════════════════════════════╝
echo.
echo 此脚本将自动完成以下操作:
echo   1. 检查 Python 环境
echo   2. 创建 Python 虚拟环境
echo   3. 安装必要的依赖包
echo   4. 安装 Playwright 浏览器
echo.
echo 预计需要 3-5 分钟，请耐心等待...
echo.
pause
echo.

REM ============================================
REM 步骤 1: 检查 Python
REM ============================================
echo [1/4] 检查 Python 环境...
python --version >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo ❌ 错误: 未找到 Python
    echo.
    echo 请先安装 Python 3.11 或更高版本
    echo 下载地址: https://www.python.org/downloads/
    echo.
    echo 安装时请勾选 "Add Python to PATH"
    echo.
    pause
    exit /b 1
)

python --version
echo ✓ Python 已安装
echo.

REM ============================================
REM 步骤 2: 创建虚拟环境（可选）
REM ============================================
echo [2/4] 准备 Python 环境...

if exist "venv\" (
    echo ✓ 虚拟环境已存在
) else (
    echo 创建虚拟环境...
    python -m venv venv
    if %ERRORLEVEL% NEQ 0 (
        echo ⚠️  虚拟环境创建失败，使用全局环境继续...
    ) else (
        echo ✓ 虚拟环境创建成功
    )
)
echo.

REM 激活虚拟环境（如果存在）
if exist "venv\Scripts\activate.bat" (
    call venv\Scripts\activate.bat
    echo ✓ 已激活虚拟环境
    echo.
)

REM ============================================
REM 步骤 3: 安装依赖
REM ============================================
echo [3/4] 安装 Python 依赖包...
echo 正在安装 playwright...
pip install playwright --upgrade
if %ERRORLEVEL% NEQ 0 (
    echo ❌ 依赖安装失败
    pause
    exit /b 1
)
echo ✓ 依赖安装完成
echo.

REM ============================================
REM 步骤 4: 安装 Playwright 浏览器
REM ============================================
echo [4/4] 安装 Playwright 浏览器驱动...
echo 这可能需要几分钟，请耐心等待...
echo.
playwright install chromium
if %ERRORLEVEL% NEQ 0 (
    echo ⚠️  浏览器驱动安装可能不完整
    echo    如果后续运行出错，请手动执行:
    echo    playwright install chromium
    echo.
) else (
    echo ✓ 浏览器驱动安装完成
)
echo.

REM ============================================
REM 安装完成
REM ============================================
echo.
echo ╔════════════════════════════════════════════════════╗
echo ║                                                    ║
echo ║              ✓ 安装完成！                         ║
echo ║                                                    ║
echo ╚════════════════════════════════════════════════════╝
echo.
echo 接下来可以:
echo   1. 双击运行 "快速开始.bat" 开始使用
echo   2. 或查看 "使用手册.md" 了解详细说明
echo.
echo 按任意键退出...
pause >nul
```

---

### 2️⃣ **快速启动脚本** - `快速开始.bat`

```batch
@echo off
chcp 65001 >nul
title AI聊天测试工具 - 快速启动
color 0B

:MENU
cls
echo.
echo ╔════════════════════════════════════════════════════╗
echo ║                                                    ║
echo ║          AI聊天自动测试工具 - 快速启动            ║
echo ║                                                    ║
echo ╚════════════════════════════════════════════════════╝
echo.
echo  请选择操作:
echo.
echo  [1] 🚀 启动 Chrome 调试模式
echo  [2] 🧪 运行测试 (Oracle 测试集)
echo  [3] 📊 查看测试报告
echo  [4] 📝 查看使用手册
echo  [5] ❌ 退出
echo.
echo ════════════════════════════════════════════════════
echo.

set /p choice="请输入选项 (1-5): "

if "%choice%"=="1" goto LAUNCH_CHROME
if "%choice%"=="2" goto RUN_TEST
if "%choice%"=="3" goto VIEW_REPORT
if "%choice%"=="4" goto VIEW_MANUAL
if "%choice%"=="5" goto EXIT

echo.
echo ⚠️  无效选项，请重新选择
timeout /t 2 /nobreak >nul
goto MENU

:LAUNCH_CHROME
cls
echo.
echo ════════════════════════════════════════════════════
echo  正在启动 Chrome 调试模式...
echo ════════════════════════════════════════════════════
echo.
echo  Chrome 将在新窗口打开
echo  请在 Chrome 中:
echo    1. 登录系统
echo    2. 进入"知识库助手"页面
echo    3. 保持窗口打开
echo.
echo  完成后返回此窗口继续操作
echo.
pause

start "" "%~dp0launch_chrome_debug.bat"

echo.
echo ✓ Chrome 已启动
echo.
echo 按任意键返回主菜单...
pause >nul
goto MENU

:RUN_TEST
cls
echo.
echo ════════════════════════════════════════════════════
echo  运行测试
echo ════════════════════════════════════════════════════
echo.

REM 检查是否已安装
if not exist "venv\" (
    echo ⚠️  检测到未安装，正在执行安装...
    call install.bat
    if %ERRORLEVEL% NEQ 0 (
        echo ❌ 安装失败
        pause
        goto MENU
    )
)

REM 激活虚拟环境
if exist "venv\Scripts\activate.bat" (
    call venv\Scripts\activate.bat
)

echo  提示: 请确保已完成以下步骤:
echo    ✓ Chrome 调试模式已启动 (选项 1)
echo    ✓ 已在 Chrome 中登录
echo    ✓ 已进入知识库助手页面
echo.
set /p confirm="确认已完成以上步骤? (y/n): "

if /i not "%confirm%"=="y" (
    echo.
    echo 返回主菜单...
    timeout /t 2 /nobreak >nul
    goto MENU
)

echo.
echo ════════════════════════════════════════════════════
echo  开始执行测试...
echo ════════════════════════════════════════════════════
echo.

REM 运行测试
python auto_chat_tester_v2.py --set question_sets/oracle_basic_001.json --database Oracle --use-existing --export both

echo.
echo ════════════════════════════════════════════════════
echo  测试执行完成
echo ════════════════════════════════════════════════════
echo.
echo 按任意键返回主菜单...
pause >nul
goto MENU

:VIEW_REPORT
cls
echo.
echo ════════════════════════════════════════════════════
echo  查看测试报告
echo ════════════════════════════════════════════════════
echo.

REM 查找最新的报告文件
for /f "delims=" %%i in ('dir /b /od report_*.md 2^>nul') do set LATEST_REPORT=%%i

if not defined LATEST_REPORT (
    echo ⚠️  未找到测试报告
    echo    请先运行测试 (选项 2)
    echo.
    pause
    goto MENU
)

echo 最新报告: %LATEST_REPORT%
echo.
start "" "%LATEST_REPORT%"

echo ✓ 已在默认程序中打开报告
echo.
echo 按任意键返回主菜单...
pause >nul
goto MENU

:VIEW_MANUAL
cls
start "" "使用手册.md"
timeout /t 2 /nobreak >nul
goto MENU

:EXIT
echo.
echo 感谢使用！
timeout /t 1 /nobreak >nul
exit /b 0
```

---

### 3️⃣ **完整使用手册** - `使用手册.md`

```markdown
# AI聊天自动测试工具 - 使用手册

## 📋 目录

1. [快速开始](#快速开始)
2. [详细步骤](#详细步骤)
3. [问题集管理](#问题集管理)
4. [常见问题](#常见问题)
5. [进阶使用](#进阶使用)

---

## 🚀 快速开始

### 新手推荐：使用一键脚本

1. **首次安装**
   - 双击运行 `install.bat`
   - 等待安装完成（约3-5分钟）

2. **开始测试**
   - 双击运行 `快速开始.bat`
   - 选择 `[1] 启动 Chrome 调试模式`
   - 在 Chrome 中登录并进入知识库助手页面
   - 返回菜单，选择 `[2] 运行测试`

3. **查看结果**
   - 测试完成后选择 `[3] 查看测试报告`

---

## 📖 详细步骤

### 步骤1：安装环境

#### 方法A：自动安装（推荐）
```cmd
双击运行: install.bat
```

#### 方法B：手动安装
```cmd
# 1. 安装依赖
pip install playwright

# 2. 安装浏览器驱动
playwright install chromium
```

### 步骤2：启动 Chrome 调试模式

#### 方法A：使用启动脚本（推荐）
```cmd
双击运行: launch_chrome_debug.bat
```

#### 方法B：手动启动
```cmd
chrome.exe --remote-debugging-port=9222 --user-data-dir="%TEMP%\chrome-debug"
```

**重要提示：**
- Chrome 启动后，进行以下操作：
  1. 输入用户名密码登录
  2. 点击进入"知识库助手"页面
  3. 确保页面 URL 包含 `rkindex-chat.html`
  4. **保持 Chrome 窗口打开**

### 步骤3：运行测试

#### 方法A：使用快速启动（推荐）
```cmd
双击运行: 快速开始.bat
选择: [2] 运行测试
```

#### 方法B：命令行运行
```cmd
# 基础用法
python auto_chat_tester_v2.py --set question_sets/oracle_basic_001.json --database Oracle --use-existing

# 生成 Markdown 报告
python auto_chat_tester_v2.py --set question_sets/oracle_basic_001.json --database Oracle --use-existing --export markdown

# 同时生成两种格式报告
python auto_chat_tester_v2.py --set question_sets/oracle_basic_001.json --database Oracle --use-existing --export both
```

### 步骤4：查看报告

测试完成后，会生成两种格式的报告：

- **JSON 报告**: `report_<问题集ID>_<时间戳>.json` - 详细的机器可读数据
- **Markdown 报告**: `report_<问题集ID>_<时间戳>.md` - 易读的格式化报告

可以用任何文本编辑器或 Markdown 查看器打开。

---

## 📝 问题集管理

### 查看现有问题集

问题集存放在 `question_sets/` 目录下：

```
question_sets/
├── oracle_basic_001.json      # Oracle 基础测试
└── (其他问题集...)
```

### 创建新问题集

1. **使用生成工具**（推荐）
   ```cmd
   python generate_questions.py
   ```

2. **手动创建 JSON 文件**

   在 `question_sets/` 目录创建新文件，格式如下：

   ```json
   {
     "set_id": "my_test_001",
     "name": "我的测试集",
     "target_database": "Oracle",
     "created_at": "2026-08-14",
     "questions": [
       {
         "id": "q001",
         "content": "你的问题内容",
         "category": "分类",
         "status": "pending",
         "priority": 1
       }
     ]
   }
   ```

### 修改问题集

直接编辑 JSON 文件即可。状态字段说明：

- `pending`: 待执行
- `completed`: 已完成
- `failed`: 执行失败
- `skipped`: 已跳过

---

## ❓ 常见问题

### Q1: 提示"连接到浏览器失败"

**原因**: Chrome 调试模式未启动

**解决方法**:
1. 确保运行了 `launch_chrome_debug.bat`
2. 或手动运行：
   ```cmd
   chrome.exe --remote-debugging-port=9222 --user-data-dir="%TEMP%\chrome-debug"
   ```
3. 检查端口是否被占用：
   ```cmd
   netstat -ano | findstr 9222
   ```

### Q2: 测试一直显示"等待回答完成"

**可能原因**:
- 网络延迟
- 知识库响应慢
- 页面元素发生变化

**解决方法**:
1. 手动检查 Chrome 窗口，查看是否真的在回答
2. 如果回答已完成但脚本未检测到，按 `Ctrl+C` 中断后重新运行
3. 查看控制台是否有错误信息

### Q3: 提示"选择知识库失败"

**原因**: 页面结构可能不同或未完全加载

**解决方法**:
1. 脚本会提示手动操作，按提示在 Chrome 中手动选择知识库
2. 选择完成后回到终端按回车继续

### Q4: 如何中断测试

按 `Ctrl+C` 可随时中断。已完成的问题会保存状态，下次运行会跳过已完成的问题。

### Q5: 如何重新测试已完成的问题

编辑问题集 JSON 文件，将对应问题的 `status` 改为 `pending`。

---

## 🔧 进阶使用

### 命令行参数说明

```cmd
python auto_chat_tester_v2.py [参数]

必需参数:
  --set          问题集文件路径
  --database     目标知识库名称

可选参数:
  --use-existing          连接到已打开的 Chrome（推荐）
  --cdp-url              Chrome 调试端口 URL（默认: http://localhost:9222）
  --export               报告格式: json / markdown / both（默认: json）
```

### 测试不同知识库

```cmd
# Oracle 知识库
python auto_chat_tester_v2.py --set question_sets/oracle_basic_001.json --database Oracle --use-existing

# Redis 知识库
python auto_chat_tester_v2.py --set question_sets/redis_test.json --database Redis --use-existing

# MySQL 知识库
python auto_chat_tester_v2.py --set question_sets/mysql_test.json --database MySQL --use-existing
```

### 同时运行多个测试

每个测试使用不同的调试端口：

```cmd
# 第一个测试（默认端口 9222）
chrome.exe --remote-debugging-port=9222 --user-data-dir="%TEMP%\chrome-debug-1"
python auto_chat_tester_v2.py --set set1.json --database Oracle --use-existing

# 第二个测试（端口 9223）
chrome.exe --remote-debugging-port=9223 --user-data-dir="%TEMP%\chrome-debug-2"
python auto_chat_tester_v2.py --set set2.json --database Redis --use-existing --cdp-url http://localhost:9223
```

### 批量测试脚本

创建 `run_all_tests.bat`:

```batch
@echo off
echo 运行所有测试...

REM 激活虚拟环境
call venv\Scripts\activate.bat

REM 执行多个测试
python auto_chat_tester_v2.py --set question_sets/oracle_basic_001.json --database Oracle --use-existing --export both
python auto_chat_tester_v2.py --set question_sets/redis_test.json --database Redis --use-existing --export both

echo 所有测试完成
pause
```

---

## 📞 技术支持

如遇到问题，请提供以下信息：

1. 错误截图或错误信息
2. Python 版本 (`python --version`)
3. 问题集文件名
4. 操作步骤

---

## 📄 文件说明

| 文件名 | 说明 |
|--------|------|
| `install.bat` | 一键安装脚本 |
| `快速开始.bat` | 交互式启动菜单 |
| `launch_chrome_debug.bat` | 启动 Chrome 调试模式 |
| `auto_chat_tester_v2.py` | 主测试脚本 |
| `question_manager.py` | 问题集管理模块 |
| `generate_questions.py` | 问题生成工具 |
| `requirements.txt` | Python 依赖列表 |
| `question_sets/` | 问题集目录 |

---

## 🔄 更新日志

### v2.0 (2026-08-14)
- ✅ 支持连接已登录的浏览器
- ✅ 改进回答完成检测（基于按钮颜色）
- ✅ 添加一键安装和启动脚本
- ✅ 完善错误处理和用户提示

### v1.0 (2026-08-13)
- ✅ 基础自动测试功能
- ✅ 问题集管理
- ✅ 进度跟踪和报告生成
```

---

### 4️⃣ **分发打包说明** - `分发说明.txt`

```text
═══════════════════════════════════════════════════
  AI聊天自动测试工具 - 分发打包说明
═══════════════════════════════════════════════════

【必需文件清单】
─────────────────────────────────────────────────

核心文件:
  ✓ auto_chat_tester_v2.py          主程序
  ✓ question_manager.py              问题集管理
  ✓ requirements.txt                 依赖列表
  
脚本文件:
  ✓ install.bat                      一键安装
  ✓ 快速开始.bat                     快速启动菜单
  ✓ launch_chrome_debug.bat          Chrome 调试启动
  
文档文件:
  ✓ 使用手册.md                      完整使用说明
  ✓ README.md                        项目说明
  
问题集:
  ✓ question_sets/                   问题集目录
    └─ oracle_basic_001.json         示例问题集

可选文件:
  □ generate_questions.py            问题生成工具
  □ manage_questions.py              问题管理工具
  □ USAGE.md                         旧版说明

【打包步骤】
─────────────────────────────────────────────────

方法1: 创建 ZIP 压缩包

  1. 创建新文件夹，命名为: AI聊天测试工具_v2.0
  
  2. 复制以下文件到文件夹:
     - auto_chat_tester_v2.py
     - question_manager.py
     - requirements.txt
     - install.bat
     - 快速开始.bat
     - launch_chrome_debug.bat
     - 使用手册.md
     - README.md
     - question_sets/ (整个目录)
  
  3. 右键文件夹 → 发送到 → 压缩(zipped)文件夹
  
  4. 分享 ZIP 文件给同事


方法2: 使用 Git 仓库

  1. 创建 .gitignore 文件，排除:
     __pycache__/
     venv/
     *.pyc
     report_*.json
     report_*.md
  
  2. 提交代码到内网 Git 仓库
  
  3. 同事克隆仓库后运行 install.bat


方法3: 网络共享文件夹

  将整个文件夹放到公司共享盘，通知同事路径


【使用前提】
─────────────────────────────────────────────────

同事电脑需要:
  ✓ Windows 操作系统
  ✓ Python 3.11+ (如未安装，install.bat 会提示)
  ✓ 网络访问权限 (安装依赖包)
  ✓ Google Chrome 浏览器


【首次使用指导】
─────────────────────────────────────────────────

发送给同事的操作步骤:

1. 解压 ZIP 文件到任意目录

2. 双击运行 install.bat (首次使用)
   - 自动安装所有依赖
   - 等待3-5分钟完成安装

3. 双击运行 快速开始.bat
   - 选择 [1] 启动 Chrome
   - 在 Chrome 中登录系统
   - 进入知识库助手页面

4. 返回菜单，选择 [2] 运行测试

5. 测试完成后，选择 [3] 查看报告

详细说明见: 使用手册.md


【技术支持】
─────────────────────────────────────────────────

如同事遇到问题，请先检查:

1. Python 是否正确安装?
   cmd 运行: python --version

2. Chrome 调试模式是否启动?
   cmd 运行: netstat -ano | findstr 9222

3. 是否已登录并在正确页面?
   URL 应包含: rkindex-chat.html

4. 查看 使用手册.md 中的"常见问题"章节


═══════════════════════════════════════════════════
```

---

## 📦 现在创建完整打包

让我帮你创建这些文件。但首先，让我询问几个问题来完善分发包：完美！ZIP 压缩包是最简单的方式。现在让我创建所有需要的文件，然后给你一个打包清单。

由于我刚才已经展示了所有关键文件的内容，现在让我创建一个**打包检查清单**和**给同事的快速指南**：

---

## ✅ 打包检查清单

创建文件 `打包清单.txt`：

```text
═══════════════════════════════════════════════════
  AI聊天自动测试工具 - 打包前检查清单
═══════════════════════════════════════════════════

【第1步】准备文件
─────────────────────────────────────────────────

创建文件夹: AI聊天测试工具_v2.0

复制以下文件到文件夹:

核心程序 (必需):
 [ ] auto_chat_tester_v2.py
 [ ] question_manager.py
 [ ] requirements.txt

脚本 (必需):
 [ ] install.bat
 [ ] 快速开始.bat
 [ ] launch_chrome_debug.bat

文档 (必需):
 [ ] 使用手册.md
 [ ] README.md
 [ ] 给同事的快速指南.txt

问题集 (必需):
 [ ] question_sets 文件夹
     [ ] oracle_basic_001.json

可选工具:
 [ ] generate_questions.py
 [ ] manage_questions.py


【第2步】测试打包
─────────────────────────────────────────────────

 [ ] 在新位置解压测试
 [ ] 运行 install.bat 确认安装成功
 [ ] 运行快速开始.bat 确认能正常启动
 [ ] 检查所有文档能正常打开


【第3步】创建 ZIP
─────────────────────────────────────────────────

 [ ] 右键文件夹 → 发送到 → 压缩文件夹
 [ ] 重命名为: AI聊天测试工具_v2.0_YYYYMMDD.zip
 [ ] 文件大小应该在 50KB 左右（不含虚拟环境）


【第4步】分发
─────────────────────────────────────────────────

 [ ] 将 ZIP 文件发送给同事
 [ ] 同时发送"给同事的快速指南.txt"内容
 [ ] 告知联系方式以便技术支持


【注意事项】
─────────────────────────────────────────────────

 ⚠️  不要包含以下文件/文件夹:
     - venv/
     - __pycache__/
     - .git/
     - report_*.json
     - report_*.md
     - *.pyc
     - .gitignore

 ✓  确保包含:
     - 所有 .py 文件
     - 所有 .bat 文件
     - 所有 .md 和 .txt 文档
     - question_sets/ 目录及其内容

═══════════════════════════════════════════════════
```

---

## 📧 给同事的快速指南

创建文件 `给同事的快速指南.txt`：

```text
═══════════════════════════════════════════════════
  AI聊天自动测试工具 - 3分钟快速上手
═══════════════════════════════════════════════════

嗨！这是一个自动化测试工具，可以批量测试 AI 知识库的问答功能。

【第一步】解压文件
─────────────────────────────────────────────────

将 ZIP 文件解压到任意位置，比如:
  D:\工作工具\AI测试工具\


【第二步】首次安装 (只需一次)
─────────────────────────────────────────────────

双击运行: install.bat

等待3-5分钟，会自动完成:
  - 检查 Python 环境
  - 安装测试工具依赖
  - 安装浏览器驱动

如果提示"未找到 Python"，需要先安装:
  https://www.python.org/downloads/
  (安装时记得勾选 "Add Python to PATH")


【第三步】开始测试
─────────────────────────────────────────────────

1. 双击运行: 快速开始.bat

2. 选择 [1] 启动 Chrome 调试模式
   - 会自动打开一个 Chrome 窗口

3. 在这个 Chrome 窗口中:
   - 输入用户名密码登录
   - 点击进入"知识库助手"
   - ⚠️  不要关闭这个窗口！

4. 返回"快速开始"菜单

5. 选择 [2] 运行测试
   - 确认已完成登录 → 输入 y
   - 程序开始自动执行测试

6. 测试完成后，选择 [3] 查看报告


【常见问题】
─────────────────────────────────────────────────

Q: 提示"连接失败"?
A: 确保完成了第三步的第2-3小步，Chrome 调试模式需要先启动

Q: 测试卡住不动?
A: 按 Ctrl+C 中断，检查 Chrome 窗口是否正常显示回答

Q: 想重新测试某个问题?
A: 编辑 question_sets/*.json 文件，将 status 改为 "pending"

Q: 如何测试不同的知识库?
A: 在"快速开始"菜单中选择对应的选项，或修改命令中的 --database 参数


【更多帮助】
─────────────────────────────────────────────────

详细说明请查看: 使用手册.md

遇到问题联系: [你的联系方式]


═══════════════════════════════════════════════════

祝使用愉快！ 🚀
```

---

## 🎁 最终总结

现在你需要做的：

### 1. 创建以下新文件（复制我给的内容）：

- ✅ `install.bat` - 一键安装脚本
- ✅ `快速开始.bat` - 交互式菜单
- ✅ `使用手册.md` - 完整文档
- ✅ `打包清单.txt` - 打包检查
- ✅ `给同事的快速指南.txt` - 3分钟上手指南

### 2. 按打包清单整理文件

创建文件夹结构：
```
AI聊天测试工具_v2.0/
├── install.bat
├── 快速开始.bat
├── launch_chrome_debug.bat
├── auto_chat_tester_v2.py
├── question_manager.py
├── requirements.txt
├── 使用手册.md
├── README.md
├── 给同事的快速指南.txt
└── question_sets/
    └── oracle_basic_001.json
```

### 3. 创建 ZIP 压缩包

右键文件夹 → 发送到 → 压缩文件夹

### 4. 分发

将 ZIP 文件发送给同事，并附上"给同事的快速指南.txt"的内容。

---

这样同事只需要：
1. 解压
2. 双击 `install.bat`
3. 双击 `快速开始.bat`

就能轻松使用了！👍