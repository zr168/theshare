"""
AI聊天自动测试主脚本 V2 - 支持连接到已登录的浏览器
使用方法:
  1. 先运行 launch_chrome_debug.bat 启动Chrome
  2. 在Chrome中手动登录并导航到知识库助手页面
  3. 运行: python auto_chat_tester_v2.py --set question_sets/oracle_basic_001.json --database Oracle --use-existing
"""
import asyncio
import argparse
import json
import os
from datetime import datetime
from playwright.async_api import async_playwright, Page
from question_manager import QuestionSetManager, QuestionSet

class AutoChatTester:
    def __init__(self, question_set_path: str, target_database: str,
                 use_existing: bool = False, cdp_url: str = None):
        self.question_set_path = question_set_path
        self.target_database = target_database
        self.use_existing = use_existing
        self.cdp_url = cdp_url or "http://localhost:9222"
        self.export_format = "json"
        self.qm = QuestionSetManager()
        self.question_set = None
        self.page = None
        self.playwright = None
        self.browser = None
        self.context = None
        self.execution_log = []

    async def init_browser(self):
        """初始化浏览器"""
        self.playwright = await async_playwright().start()

        if self.use_existing:
            # 连接到已打开的浏览器（带远程调试）
            print(f"连接到已打开的浏览器: {self.cdp_url}")
            try:
                self.browser = await self.playwright.chromium.connect_over_cdp(self.cdp_url)
                # 获取现有的上下文和页面
                contexts = self.browser.contexts
                if contexts:
                    self.context = contexts[0]
                    pages = self.context.pages
                    if pages:
                        self.page = pages[0]
                        print(f"使用现有页面: {self.page.url}")
                    else:
                        self.page = await self.context.new_page()
                        print("创建新页面")
                else:
                    # 如果没有上下文，创建一个新的
                    self.context = await self.browser.new_context()
                    self.page = await self.context.new_page()
                    print("创建新的上下文和页面")
            except Exception as e:
                print(f"连接到浏览器失败: {e}")
                print("\n请确保:")
                print("1. Chrome 已经以调试模式启动")
                print("2. 运行命令: launch_chrome_debug.bat")
                print("3. 或手动运行: chrome.exe --remote-debugging-port=9222 --user-data-dir=\"%TEMP%\\chrome-debug\"")
                raise
        else:
            # 启动新的浏览器
            print("启动新的浏览器实例")
            self.browser = await self.playwright.chromium.launch(headless=False)
            self.context = await self.browser.new_context()
            self.page = await self.context.new_page()

    async def cleanup(self):
        """清理浏览器资源"""
        if not self.use_existing:
            # 只有在不是使用现有浏览器时才关闭
            if self.context:
                await self.context.close()
            if self.browser:
                await self.browser.close()
        if self.playwright:
            await self.playwright.stop()

    async def navigate_to_chat(self, url: str = "http://118.113.15.18:8015/ai-chat-ui/rkindex-chat.html"):
        """导航到聊天页面"""
        current_url = self.page.url
        print(f"当前页面: {current_url}")

        # 如果已经在目标页面，就不需要导航
        if url in current_url:
            print("已经在目标页面")
            await self.page.wait_for_load_state('networkidle')
            return

        print(f"导航到: {url}")
        await self.page.goto(url, wait_until='networkidle')

        # 检查是否被重定向到登录页
        await self.page.wait_for_timeout(2000)
        final_url = self.page.url
        if 'rkindex-chat.html' not in final_url:
            print(f"\n⚠️  警告: 页面被重定向到 {final_url}")
            print("=" * 60)
            print("请按以下步骤操作:")
            print("1. 在浏览器中手动登录")
            print("2. 点击进入知识库助手页面 (rkindex-chat.html)")
            print("3. 完成后回到这里按回车继续...")
            print("=" * 60)
            input()
            # 等待用户手动导航，最长5分钟
            try:
                await self.page.wait_for_url('**/rkindex-chat.html', timeout=300000)
                print("✓ 检测到正确页面，继续执行")
            except:
                print("未检测到页面变化，继续尝试...")

    async def select_database(self):
        """选择知识库"""
        try:
            select = self.page.locator('#databaseSelect')
            await select.wait_for(state='visible', timeout=10000)
            await select.select_option(self.target_database)
            print(f"✓ 已选择知识库: {self.target_database}")
            await self.page.wait_for_timeout(1000)
        except Exception as e:
            print(f"选择知识库失败: {e}")
            print("请手动选择知识库，然后按回车继续...")
            input()

    async def is_answering(self) -> bool:
        """
        检测是否正在回答
        通过检查停止按钮的背景颜色来判断：
        - 红色 (#DC2626) = 正在回答（激活状态）
        - 白色 (#FFFFFF) = 空闲状态
        """
        try:
            stop_btn = self.page.locator('#stopAskBtn')

            # 检查按钮是否存在和可见
            is_visible = await stop_btn.is_visible()
            if not is_visible:
                return False

            # 获取按钮的背景颜色
            bg_color = await stop_btn.evaluate(
                '''el => {
                    const style = window.getComputedStyle(el);
                    return style.backgroundColor;
                }'''
            )

            # 打印调试信息（可选）
            # print(f"  [调试] 停止按钮背景色: {bg_color}")

            # 解析颜色值
            # backgroundColor 可能返回 rgb(220, 38, 38) 或 rgba(220, 38, 38, 1)
            # 红色激活状态: rgb(220, 38, 38) 或 #DC2626
            # 白色空闲状态: rgb(255, 255, 255) 或 #FFFFFF

            if bg_color:
                # 标准化颜色字符串
                bg_color_lower = bg_color.lower().replace(' ', '')

                # 检查是否是红色（激活状态）
                # rgb(220, 38, 38) 或 rgba(220, 38, 38, ...)
                if 'rgb(220,38,38)' in bg_color_lower or 'rgba(220,38,38' in bg_color_lower:
                    return True

                # 如果是白色或其他浅色，说明未激活
                if 'rgb(255,255,255)' in bg_color_lower or 'rgba(255,255,255' in bg_color_lower:
                    return False

                # 额外检查：通过RGB值判断是否接近红色
                import re
                rgb_match = re.search(r'rgba?\((\d+),(\d+),(\d+)', bg_color_lower)
                if rgb_match:
                    r, g, b = int(rgb_match.group(1)), int(rgb_match.group(2)), int(rgb_match.group(3))
                    # 红色：R值高，G和B值低
                    if r > 200 and g < 50 and b < 50:
                        return True
                    # 白色或浅色：RGB都很高
                    if r > 240 and g > 240 and b > 240:
                        return False

            # 作为备用方案，检查 active 类
            has_active_class = await stop_btn.evaluate(
                'el => el.classList.contains("stop-ask-btn--active")'
            )
            return has_active_class

        except Exception as e:
            print(f"  [调试] 检测回答状态时出错: {e}")
            return False

    async def wait_for_answer_start(self, timeout: int = 10):
        """等待回答开始（停止按钮变为红色激活状态）"""
        print("  ⏳ 等待回答开始...")
        start_time = datetime.now()

        while True:
            elapsed = (datetime.now() - start_time).total_seconds()
            if elapsed > timeout:
                print(f"  ⚠️  等待回答开始超时（{timeout}秒）")
                return False

            # 检查停止按钮是否激活（变红）
            if await self.is_answering():
                print("  ✓ 回答已开始（停止按钮已激活）")
                return True

            await self.page.wait_for_timeout(300)  # 更短的间隔以快速检测

    async def wait_for_answer_complete(self, timeout: int = 300):
        """
        等待回答完成
        主要方法：检查停止按钮背景色从红色变回白色
        辅助验证：检查是否出现了"耗时X秒"的标志
        """
        print("  ⏳ 等待回答完成...")
        start_time = datetime.now()
        last_check_time = start_time

        # 先等待一小段时间，确保回答真正开始
        await self.page.wait_for_timeout(1000)

        while True:
            elapsed = (datetime.now() - start_time).total_seconds()
            if elapsed > timeout:
                print(f"  ⚠️  等待超时（{timeout}秒）")
                return False

            # 检查停止按钮状态（通过背景颜色）
            is_still_answering = await self.is_answering()

            if is_still_answering:
                # 仍在回答中
                # 每5秒输出一次进度
                if (datetime.now() - last_check_time).total_seconds() >= 5:
                    print(f"  ... 回答中 (已等待 {int(elapsed)} 秒)")
                    last_check_time = datetime.now()
            else:
                # 停止按钮已变回白色（失活），说明回答可能结束
                # 等待1秒再次确认，避免误判
                await self.page.wait_for_timeout(1000)

                # 二次确认
                is_still_answering = await self.is_answering()
                if not is_still_answering:
                    # 辅助验证：尝试检测"耗时X秒"标志
                    try:
                        # 查找最后一个包含"耗时"的元素
                        timing_element = self.page.locator('.parser-info:has-text("耗时")').last
                        if await timing_element.is_visible(timeout=2000):
                            timing_text = await timing_element.inner_text()
                            print(f"  ✓ 回答完成 ({timing_text.strip()})")
                        else:
                            print("  ✓ 回答完成（停止按钮已失活）")
                    except:
                        print("  ✓ 回答完成（停止按钮已失活）")

                    return True

            await self.page.wait_for_timeout(1000)  # 每秒检查一次

    async def send_message(self, message: str) -> bool:
        """发送消息"""
        try:
            # 定位输入框
            input_box = self.page.locator('#messageInput')
            await input_box.fill(message)

            # 等待发送按钮启用
            send_btn = self.page.locator('.send-btn')
            await send_btn.wait_for(state='visible', timeout=5000)

            # 点击发送
            await send_btn.click()
            print(f"  📤 已发送: {message[:50]}...")
            return True
        except Exception as e:
            print(f"  ❌ 发送消息失败: {e}")
            return False

    async def execute_question(self, question):
        """执行单个问题"""
        print(f"\n{'='*60}")
        print(f"执行问题 {question.id}: {question.content[:80]}...")
        print(f"{'='*60}")

        # 发送消息
        success = await self.send_message(question.content)
        if not success:
            self.question_set.update_question_status(question.id, "failed", "发送消息失败")
            return False

        # 等待回答开始（按钮变红）
        started = await self.wait_for_answer_start(timeout=10)
        if not started:
            print("  ⚠️  警告: 未检测到回答开始，直接等待完成...")

        # 等待回答完成（按钮变回白色）
        completed = await self.wait_for_answer_complete()

        if completed:
            self.question_set.update_question_status(question.id, "completed")
            self.execution_log.append({
                "question_id": question.id,
                "content": question.content,
                "status": "completed",
                "timestamp": datetime.now().isoformat()
            })
            return True
        else:
            self.question_set.update_question_status(question.id, "failed", "等待回答超时")
            return False

    async def run(self):
        """运行测试"""
        # 加载问题集
        print(f"\n📂 加载问题集: {self.question_set_path}")
        self.question_set = self.qm.load(self.question_set_path)

        # 显示统计
        stats = self.question_set.get_stats()
        print(f"\n" + "="*60)
        print(f"问题集: {self.question_set.name}")
        print(f"目标知识库: {self.question_set.target_database}")
        print(f"进度: {stats['progress']}")
        print(f"  总数: {stats['total']}")
        print(f"  已完成: {stats['completed']}")
        print(f"  待执行: {stats['pending']}")
        print(f"  失败: {stats['failed']}")
        print("="*60 + "\n")

        # 初始化浏览器
        await self.init_browser()
        try:
            # 导航到页面
            await self.navigate_to_chat()

            # 选择知识库
            await self.select_database()

            print("\n🚀 开始执行测试...\n")

            # 循环执行问题
            while True:
                question = self.question_set.get_next_pending()
                if not question:
                    print("\n" + "="*60)
                    print("✅ 所有问题已执行完毕")
                    print("="*60)
                    break

                # 显示进度
                stats = self.question_set.get_stats()
                progress_bar = self._generate_progress_bar(stats['completed'], stats['total'])
                print(f"\n进度: {progress_bar} {stats['progress']}")

                # 执行问题
                await self.execute_question(question)

                # 保存进度
                self.qm.save(self.question_set, self.question_set_path)

                # 间隔
                await self.page.wait_for_timeout(2000)

            # 生成报告
            self._generate_report(self.export_format)

        finally:
            await self.cleanup()

    def _generate_progress_bar(self, completed: int, total: int) -> str:
        """生成进度条"""
        if total == 0:
            return "[░░░░░░░░░░] 0/0"
        ratio = completed / total
        filled = int(ratio * 10)
        bar = "█" * filled + "░" * (10 - filled)
        return f"[{bar}] {completed}/{total}"

    def _generate_report(self, export_format: str = "json"):
        """生成执行报告"""
        stats = self.question_set.get_stats()

        report = {
            "set_id": self.question_set.set_id,
            "name": self.question_set.name,
            "target_database": self.question_set.target_database,
            "executed_at": datetime.now().isoformat(),
            "stats": stats,
            "execution_log": self.execution_log
        }

        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')

        # 保存JSON报告
        if export_format in ["json", "both"]:
            json_path = f"report_{self.question_set.set_id}_{timestamp}.json"
            with open(json_path, 'w', encoding='utf-8') as f:
                json.dump(report, f, ensure_ascii=False, indent=2)
            print(f"\n📄 JSON报告已保存: {json_path}")

        # 保存Markdown报告
        if export_format in ["markdown", "both"]:
            md_path = f"report_{self.question_set.set_id}_{timestamp}.md"
            self._generate_markdown_report(report, md_path)
            print(f"📄 Markdown报告已保存: {md_path}")

        print(f"\n📊 执行统计:")
        print(f"  总计: {stats['total']}")
        print(f"  完成: {stats['completed']}")
        print(f"  失败: {stats['failed']}")

    def _generate_markdown_report(self, report: dict, output_path: str):
        """生成Markdown格式报告"""
        lines = [
            f"# {report['name']} 执行报告",
            "",
            f"**问题集ID**: {report['set_id']}",
            f"**目标知识库**: {report['target_database']}",
            f"**执行时间**: {report['executed_at']}",
            "",
            "## 执行统计",
            "",
            f"- 总问题数: {report['stats']['total']}",
            f"- 已完成: {report['stats']['completed']}",
            f"- 失败: {report['stats']['failed']}",
            f"- 跳过: {report['stats']['skipped']}",
            f"- 待执行: {report['stats']['pending']}",
            "",
            "## 执行详情",
            ""
        ]

        for log in report['execution_log']:
            status_icon = "✅" if log['status'] == "completed" else "❌"
            lines.append(f"{status_icon} **{log['question_id']}** - {log['content']}")
            lines.append(f"   状态: {log['status']}")
            lines.append(f"   时间: {log['timestamp']}")
            lines.append("")

        with open(output_path, 'w', encoding='utf-8') as f:
            f.write('\n'.join(lines))

async def main():
    parser = argparse.ArgumentParser(
        description='AI聊天自动测试脚本 V2 - 支持连接已登录浏览器',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
使用示例:
  # 方式1: 连接到已登录的Chrome（推荐）
  1. 先运行: launch_chrome_debug.bat
  2. 在Chrome中手动登录并进入知识库助手页面
  3. 运行测试:
     python auto_chat_tester_v2.py --set question_sets/oracle_basic_001.json --database Oracle --use-existing

  # 方式2: 启动新浏览器（需要每次登录）
  python auto_chat_tester_v2.py --set question_sets/oracle_basic_001.json --database Oracle
        """
    )
    parser.add_argument('--set', required=True, help='问题集文件路径')
    parser.add_argument('--database', required=True, help='目标知识库名称')
    parser.add_argument('--use-existing', action='store_true',
                       help='连接到已打开的Chrome浏览器（需要先运行 launch_chrome_debug.bat）')
    parser.add_argument('--cdp-url', default='http://localhost:9222',
                       help='Chrome DevTools Protocol URL（默认: http://localhost:9222）')
    parser.add_argument('--export', default='json', choices=['json', 'markdown', 'both'],
                       help='报告导出格式')

    args = parser.parse_args()

    tester = AutoChatTester(
        question_set_path=args.set,
        target_database=args.database,
        use_existing=args.use_existing,
        cdp_url=args.cdp_url
    )

    tester.export_format = args.export

    try:
        await tester.run()
    except KeyboardInterrupt:
        print("\n\n⚠️  用户中断执行")
    except Exception as e:
        print(f"\n\n❌ 执行出错: {e}")
        raise

if __name__ == "__main__":
    asyncio.run(main())
