@echo off
chcp 65001 >nul
title AI聊天测试工具 - 快速启动
color 0B

:MENU
cls
echo.
echo ╔════════════════════════════════════════════════════╗
echo ║                                                    ║
echo ║          AI聊天自动测试工具 - 快速启动            ║
echo ║                                                    ║
echo ╚════════════════════════════════════════════════════╝
echo.
echo  请选择操作:
echo.
echo  [1] 🚀 启动 Chrome 调试模式
echo  [2] 🧪 运行测试 (Oracle 测试集)
echo  [3] 📊 查看测试报告
echo  [4] 📝 查看使用手册
echo  [5] ❌ 退出
echo.
echo ════════════════════════════════════════════════════
echo.

set /p choice="请输入选项 (1-5): "

if "%choice%"=="1" goto LAUNCH_CHROME
if "%choice%"=="2" goto RUN_TEST
if "%choice%"=="3" goto VIEW_REPORT
if "%choice%"=="4" goto VIEW_MANUAL
if "%choice%"=="5" goto EXIT

echo.
echo ⚠️  无效选项，请重新选择
timeout /t 2 /nobreak >nul
goto MENU

:LAUNCH_CHROME
cls
echo.
echo ════════════════════════════════════════════════════
echo  正在启动 Chrome 调试模式...
echo ════════════════════════════════════════════════════
echo.
echo  Chrome 将在新窗口打开
echo  请在 Chrome 中:
echo    1. 登录系统
echo    2. 进入"知识库助手"页面
echo    3. 保持窗口打开
echo.
echo  完成后返回此窗口继续操作
echo.
pause

start "" "%~dp0launch_chrome_debug.bat"

echo.
echo ✓ Chrome 已启动
echo.
echo 按任意键返回主菜单...
pause >nul
goto MENU

:RUN_TEST
cls
echo.
echo ════════════════════════════════════════════════════
echo  运行测试
echo ════════════════════════════════════════════════════
echo.

REM 检查是否已安装
if not exist "venv\" (
    echo ⚠️  检测到未安装，正在执行安装...
    call install.bat
    if %ERRORLEVEL% NEQ 0 (
        echo ❌ 安装失败
        pause
        goto MENU
    )
)

REM 激活虚拟环境
if exist "venv\Scripts\activate.bat" (
    call venv\Scripts\activate.bat
)

echo  提示: 请确保已完成以下步骤:
echo    ✓ Chrome 调试模式已启动 (选项 1)
echo    ✓ 已在 Chrome 中登录
echo    ✓ 已进入知识库助手页面
echo.
set /p confirm="确认已完成以上步骤? (y/n): "

if /i not "%confirm%"=="y" (
    echo.
    echo 返回主菜单...
    timeout /t 2 /nobreak >nul
    goto MENU
)

echo.
echo ════════════════════════════════════════════════════
echo  开始执行测试...
echo ════════════════════════════════════════════════════
echo.

REM 运行测试
python auto_chat_tester_v2.py --set question_sets/oracle_basic_001.json --database Oracle --use-existing --export both

echo.
echo ════════════════════════════════════════════════════
echo  测试执行完成
echo ════════════════════════════════════════════════════
echo.
echo 按任意键返回主菜单...
pause >nul
goto MENU

:VIEW_REPORT
cls
echo.
echo ════════════════════════════════════════════════════
echo  查看测试报告
echo ════════════════════════════════════════════════════
echo.

REM 查找最新的报告文件
for /f "delims=" %%i in ('dir /b /od report_*.md 2^>nul') do set LATEST_REPORT=%%i

if not defined LATEST_REPORT (
    echo ⚠️  未找到测试报告
    echo    请先运行测试 (选项 2)
    echo.
    pause
    goto MENU
)

echo 最新报告: %LATEST_REPORT%
echo.
start "" "%LATEST_REPORT%"

echo ✓ 已在默认程序中打开报告
echo.
echo 按任意键返回主菜单...
pause >nul
goto MENU

:VIEW_MANUAL
cls
start "" "使用手册.md"
timeout /t 2 /nobreak >nul
goto MENU

:EXIT
echo.
echo 感谢使用！
timeout /t 1 /nobreak >nul
exit /b 0
