"""
问题集管理模块
处理问题集的加载、保存、状态跟踪和统计
"""
import json
import os
from datetime import datetime
from typing import Dict, List, Optional
from dataclasses import dataclass, asdict


@dataclass
class Question:
    id: str
    content: str
    category: str
    status: str = "pending"  # pending, completed, failed, skipped
    priority: int = 1
    last_run: Optional[str] = None
    retry_count: int = 0
    error_message: Optional[str] = None


@dataclass
class QuestionSet:
    set_id: str
    name: str
    target_database: str
    created_at: str
    questions: List[Question]

    def get_stats(self) -> Dict:
        """获取问题集统计信息"""
        total = len(self.questions)
        completed = sum(1 for q in self.questions if q.status == "completed")
        failed = sum(1 for q in self.questions if q.status == "failed")
        skipped = sum(1 for q in self.questions if q.status == "skipped")
        pending = total - completed - failed - skipped
        return {
            "total": total,
            "completed": completed,
            "failed": failed,
            "skipped": skipped,
            "pending": pending,
            "progress": f"{completed}/{total}" if total > 0 else "0/0"
        }

    def get_next_pending(self) -> Optional[Question]:
        """获取下一个待执行的问题"""
        for question in self.questions:
            if question.status == "pending":
                return question
        return None

    def update_question_status(self, question_id: str, status: str, error_message: str = None):
        """更新问题状态"""
        for question in self.questions:
            if question.id == question_id:
                question.status = status
                question.last_run = datetime.now().isoformat()
                if status == "failed":
                    question.retry_count += 1
                    question.error_message = error_message
                break


class QuestionSetManager:
    def __init__(self, question_sets_dir: str = "question_sets"):
        self.question_sets_dir = question_sets_dir
        if not os.path.exists(question_sets_dir):
            os.makedirs(question_sets_dir)

    def load(self, set_path: str) -> QuestionSet:
        """加载问题集"""
        with open(set_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        questions = [Question(**q) for q in data['questions']]
        return QuestionSet(
            set_id=data['set_id'],
            name=data['name'],
            target_database=data['target_database'],
            created_at=data['created_at'],
            questions=questions
        )

    def save(self, question_set: QuestionSet, set_path: str = None):
        """保存问题集"""
        if set_path is None:
            set_path = os.path.join(self.question_sets_dir, f"{question_set.set_id}.json")
        
        data = {
            "set_id": question_set.set_id,
            "name": question_set.name,
            "target_database": question_set.target_database,
            "created_at": question_set.created_at,
            "questions": [asdict(q) for q in question_set.questions]
        }
        
        with open(set_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    def list_sets(self) -> List[str]:
        """列出所有问题集文件"""
        if not os.path.exists(self.question_sets_dir):
            return []
        return [f for f in os.listdir(self.question_sets_dir) if f.endswith('.json')]

    def create_set(self, set_id: str, name: str, target_database: str, questions: List[Dict]) -> QuestionSet:
        """创建新问题集"""
        question_objs = [Question(**q) for q in questions]
        question_set = QuestionSet(
            set_id=set_id,
            name=name,
            target_database=target_database,
            created_at=datetime.now().isoformat(),
            questions=question_objs
        )
        self.save(question_set)
        return question_set

    def extract_questions_from_report(self, report_path: str, new_set_id: str, new_name: str) -> QuestionSet:
        """从执行报告中提取问题创建新问题集"""
        with open(report_path, 'r', encoding='utf-8') as f:
            report = json.load(f)
        
        # 重置所有问题状态为pending
        new_questions = []
        for log in report['execution_log']:
            new_questions.append({
                "id": log['question_id'],
                "content": log['content'],
                "category": "从报告提取",
                "status": "pending",
                "priority": 1
            })
        
        question_set = self.create_set(
            set_id=new_set_id,
            name=new_name,
            target_database=report['target_database'],
            questions=new_questions
        )
        return question_set